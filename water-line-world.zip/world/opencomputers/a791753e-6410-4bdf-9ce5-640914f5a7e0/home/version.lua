local versions = {
  programVersion = "1.0.1",
  configVersion = 1
}

return versions
